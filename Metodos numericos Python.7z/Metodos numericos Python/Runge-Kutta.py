# -*- coding: utf-8 -*-
"""
Created on Wed Jun 10 22:49:56 2020

@author: mhrv9
"""


import matplotlib.pyplot as plt
from tabulate import tabulate
from math import *

def calculate ():
    #
    #Lee x(0) y x(1)
    #
    print('Ingresa los intervalos para calcular las iteraciones')
    while True:
            try:
                x = float(input('¿Cuanto vale x(0)? '))
                break
            except ValueError:
                print('Escribe un numero valido')
    while True:
            try:
                x_final = float(input('¿Cuanto vale x(final)? '))
                break
            except ValueError:
                print('Escribe un numero valido')
    #
    #Lee y(0)
    #
    while True:
            try:
                y = float(input('¿Cuanto vale y(0)? '))
                break
            except ValueError:
                print('Escribe un numero valido')
    #
    #Pregunta si se conoce el valor de n o h
    #
    while True:
        try:
            question = str(input('¿Conoces n o h? Escribe n || h: '))
            if question.upper() in ['N', 'H']:
                break
            else:
                print('Escribe n o h')
        except ValueError:
            print('Escribe n o h')
    #
    #Cuando la respuesta es n
    #
    if (question == 'n'):
        while True:
            try:
                n = int(input('¿Cuantos subintervalos va a calcular? '))
                break
            except ValueError:
                print('Escribe un numero valido')
        h = float((x_final - x) / n)
    #
    #Cuando la respuesta es h
    #
    else:
        while True:
            try:
                h = float(input('¿Cuanto vale el intervalo? '))
                break
            except ValueError:
                print('Escribe un numero valido')
        n = int((x_final - x) / h)
    #
    #Lee la función
    #
    while True:
        try:
            print('Ejemplo de función: √y/2x+1 se escribe --> sqrt(y)/((2*x)+1)')
            f = str(input('Escribe la función: '))
            break
        except ValueError:
            print('Escribe un numero valido')
    #
    #Hace las iteraciones
    #
    x = 0 #Se inicaliza x en 0
    solve_x = []
    solve_y = []
    solve_x.append(x)
    solve_y.append(y)
    #
    #Se crean otras variables para el 4o orden
    #
    y_4 = y
    solve_y_4 = []
    solve_y_4.append(y)
    for i in range (0, n):
        expr = eval(f)
        #2o orden
        k_0 = expr
        k_1 = (x + h) - (y + (h*k_0))
        y = y + (h/2*(k_0 + k_1))
        #2o orden
        
        #4o orden
        k_1_4 = expr
        k_2_4 = ((x + (h/2)) - (y_4 + (h*(k_1_4/2))))
        k_3_4 = ((x + (h/2)) - (y_4 + (h*(k_2_4/2))))
        k_4_4 = ((x + h) - (y_4 + (h*k_3_4)))
        y_4 = y_4 + ((h/6)*(k_1_4 + (2 * k_2_4) + (2 * k_3_4) + k_4_4))
        #4o orden
        x = x + h
        solve_x.append(x)
        solve_y.append(y)
        solve_y_4.append(y_4)
    return solve_x, solve_y, solve_y_4

def graph (results_x, results_y, results_y_4):
    iteration_num = len(results_x)
    x = ([[None]]*(iteration_num))
    y = ([[None]]*(iteration_num))
    y_4 = ([[None]]*(iteration_num)) 
    for i in range (0, iteration_num):
        x[i] = [results_x[i]]
        y[i] = [results_y[i]]
        y_4[i] = [results_y_4[i]]
    iteration_num = iteration_num - 1
    if x[0] < x[iteration_num] and y[0] < y[iteration_num]:
        x.sort()
        y.sort()
        y_4.sort()
    else:
        if x[0] > x[iteration_num] and y[0] > y[iteration_num]:
            x.sort(reverse=True)
            y.sort(reverse=True)
            y_4.sort(reverse=True)
        else:
            if x[0] > x[iteration_num]:
                x.sort(reverse=True)
                y.sort()
                y_4.sort()
            else:
                if y[0] > y[iteration_num]:
                    x.sort()
                    y.sort(reverse=True)
                    y_4.sort(reverse=True)
    plt.xlabel('Xi')
    plt.ylabel('Yi')
    plt.title('Runge - Kutta || Azul = 2o || Rojo = 4o')
    #2o orden
    plt.plot(x, y, c='b')
    #4o orden
    plt.plot(x, y_4, c='r')
    plt.show()
    
def print_table (results_x, results_y, results_y_4):
    iteration_num = len(results_x)
    table = ([[None]]*iteration_num)
    headers = ['Iteraciones', 'Xi 2o Orden', 'Yi 2o Orden', 'Xi 4o Orden', 'Yi 4o Orden']
    for i in range (0, iteration_num):
        table[i] = [i, results_x[i], results_y[i], results_x[i], results_y_4[i]]
        
    print (tabulate(table, headers, tablefmt='fancy_grid', floatfmt = ".4f"))
    #
    #Calcula e imprime el error entre el 2o y el 4o grado
    #
    error = ((results_y_4[iteration_num-1] - results_y[iteration_num-1]) / results_y_4[iteration_num-1]) * 100
    print ('Resultado')
    print('Error = {:.4f} - {:.4f} / {:.4f} * 100'.format(float(results_y_4[iteration_num-1]), 
                                                          float(results_y[iteration_num-1]), 
                                                          float(results_y_4[iteration_num-1])))
    print('Error = {:.4f}%'.format(abs(error)))

if __name__ == '__main__':
    print('Guia de comandos')
    print(eval('dir()'))
    results_x, results_y, results_y_4 = calculate ()
    graph(results_x, results_y, results_y_4)
    print_table(results_x, results_y, results_y_4)